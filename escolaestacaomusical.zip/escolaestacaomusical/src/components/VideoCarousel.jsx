import React from 'react'

const videos = [
  { src: '/videos/video01.mp4', poster: '/img/foto01.webp' },
  { src: '/videos/video02.mp4', poster: '/img/foto02.webp' },
  { src: '/videos/video03.mp4', poster: '/img/foto03.webp' },
  { src: '/videos/video04.mp4', poster: '/img/foto04.webp' },
  { src: '/videos/video05.mp4', poster: '/img/foto05.webp' },
  { src: '/videos/video06.mp4', poster: '/img/foto06.webp' },
]

export default function VideoCarousel() {
  return (
    <div className="carousel">
      {videos.map((v,i)=> (
        <video key={i} src={v.src} poster={v.poster} controls preload="metadata" />
      ))}
    </div>
  )
}
