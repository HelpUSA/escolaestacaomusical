import React from 'react'
import { useTranslation } from 'react-i18next'
import { SITE } from '../site.config'

export default function Footer() {
  const { t } = useTranslation()
  const year = new Date().getFullYear()
  return (
    <footer>
      <div className="container" style={{display:'grid', gap:8}}>
        <div><strong>Instagram:</strong> <a href={SITE.instagram} target="_blank" rel="noreferrer">@escola.estacaomusical</a></div>
        <div><strong>Email:</strong> <a href={`mailto:${SITE.email}`}>{SITE.email}</a></div>
        <div><strong>{t('contact.address_label')}:</strong> {SITE.address}</div>
        <div style={{color:'var(--muted)'}}>{t('footer.rights', {year})}</div>
      </div>
    </footer>
  )
}
