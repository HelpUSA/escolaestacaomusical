import React from 'react'
import { useTranslation } from 'react-i18next'
import Header from './components/Header'
import VideoCarousel from './components/VideoCarousel'
import ImageGrid from './components/ImageGrid'
import FloatingWhatsApp from './components/FloatingWhatsApp'

export default function App() {
  const { t } = useTranslation()
  return (
    <>
      <Header />
      <main id="home" className="hero">
        <section className="card">
          <h1 style={{marginTop:0}}>{t('hero.title')}</h1>
          <p style={{color:'var(--muted)'}}>{t('hero.subtitle')}</p>
          <div style={{marginTop:16}}>
            <a className="lang" href="#contact">{t('menu.contact')}</a>
          </div>
          <div style={{marginTop:18}}>
            <VideoCarousel />
          </div>
        </section>
        <aside className="card">
          <img src="/img/logo.jpg" alt="Logo Escola Estação Musical" style={{width:'100%', borderRadius:12}} />
          <h3 style={{marginBottom:8}}>{t('about.title')}</h3>
          <p style={{color:'var(--muted)'}}>{t('about.text')}</p>
        </aside>
      </main>

      <section id="gallery" className="container" style={{marginTop:24}}>
        <h2 style={{margin:'12px 0'}}>{t('gallery.title')}</h2>
        <div className="card">
          <ImageGrid />
        </div>
      </section>

      <section id="contact" className="container" style={{marginTop:24}}>
        <div className="card" style={{display:'grid', gap:10}}>
          <h2 style={{margin:'0 0 6px 0'}}>{t('contact.title')}</h2>
          <iframe
            title="Mapa"
            style={{width:'100%', height:300, border:0, borderRadius:12}}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            src="https://www.google.com/maps?q=Av.+Gov.+Fl%C3%A1vio+Ribeiro+Coutinho,+167+-+Mana%C3%ADra,+Jo%C3%A3o+Pessoa&output=embed">
          </iframe>
        </div>
      </section>

      <FloatingWhatsApp />
      <div className="container"><div className="card" style={{marginTop:24}}><small>Site inicial inspirado no layout da CG Details.</small></div></div>
      <div className="container"><div className="card" style={{marginTop:12}}><small>Substitua os vídeos/imagens pelos arquivos reais.</small></div></div>
      <div className="container"><div className="card" style={{marginTop:12}}><small>Para alterar textos, edite as traduções em <code>src/i18n</code>.</small></div></div>
      
    </>
  )
}

import Footer from './components/Footer'

// Append Footer at end
