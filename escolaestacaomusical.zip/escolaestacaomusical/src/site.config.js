export const SITE = {
  brand: "Escola Estação Musical",
  instagram: "https://www.instagram.com/escola.estacaomusical/",
  whatsapp: "+5583999999999", // <-- coloque o número real aqui com DDI
  address: "Empresarial Kadoshi - Av. Gov. Flávio Ribeiro Coutinho, 167 - Sala 210 - Manaíra, João Pessoa, Brazil 58037-000",
  email: "contato@escolaestacaomusical.com.br"
}
