import React from 'react'
import { useTranslation } from 'react-i18next'
export default function Header(){
  const { t, i18n } = useTranslation()
  const changeLang = (lng)=> i18n.changeLanguage(lng)
  return (
    <header>
      <div className="container" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div className="brand">
          <img src="/img/logo.jpg" alt="Logo" />
          <span>Escola Estação Musical</span>
        </div>
        <nav>
          <a href="#home">{t('menu.home')}</a>
          <a href="#gallery">{t('menu.gallery')}</a>
          <a href="#contact">{t('menu.contact')}</a>
          <span className="lang" onClick={()=>changeLang('pt')}>PT</span>
          <span className="lang" onClick={()=>changeLang('en')}>EN</span>
          <span className="lang" onClick={()=>changeLang('es')}>ES</span>
        </nav>
      </div>
    </header>
  )
}
